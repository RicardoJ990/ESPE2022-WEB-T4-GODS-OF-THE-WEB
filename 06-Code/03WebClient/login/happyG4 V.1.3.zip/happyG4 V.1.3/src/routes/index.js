const express = require('express');
const router = express.Router();
const model = require(`../model/task`);

router.get('/', (req, res) => {
    res.render('index', {
        title: 'FRUIT SHOP HAPPY-AVOCADO',
        task: []        
    });
});

router.post('/add', (req, res) =>{
    let body = req.body;
    body.status = false;

    console.log(body);
    
       

    //console.log(body);
});

module.exports = router;


